package com.jbmegamart.kitchen.data.model

import kotlinx.serialization.Serializable

@Serializable
data class LoginRequest(
    val username: String,
    val password: String
)

@Serializable
data class UserDto(
    val id: Int,
    val name: String,
    val role: String,
    val createdAt: String? = null
)

@Serializable
data class LoginResponse(
    val user: UserDto
)

@Serializable
data class CategoryDto(
    val id: String,
    val name: String,
    val displayOrder: Int? = 0,
    val image: String? = null,
    val hasSubcategories: Boolean? = false
)

@Serializable
data class SubcategoryDto(
    val id: String,
    val categoryId: String,
    val name: String,
    val displayOrder: Int? = 0,
    val image: String? = null
)

@Serializable
data class ProductDto(
    val id: String,
    val name: String,
    val price: Double? = null,
    val costPrice: Double? = 0.0,
    val image: String? = null,
    val categoryId: String? = null,
    val subcategoryId: String? = null,
    val variant: String? = null,
    val isOutOfStock: Boolean = false,
    val isSpecial: Boolean = false,
    val displayOrder: Int? = 0
)

@Serializable
data class OrderItemDto(
    val id: String,
    val name: String,
    val price: Double? = null,
    val costPrice: Double? = null,
    val quantity: Int = 1,
    val variant: String? = null,
    val instructions: String? = null
)

@Serializable
data class OrderDto(
    val id: String,
    val customerName: String,
    val customerPhone: String? = null,
    val address: String? = null,
    val items: List<OrderItemDto> = emptyList(),
    val total: Double = 0.0,
    val totalCost: Double? = null,
    val profit: Double? = null,
    val status: String = "Pending",
    val paymentMethod: String = "COD",
    val taxAmount: Double = 0.0,
    val taxRate: Double = 0.16,
    val createdAt: String? = null
)

@Serializable
data class CreateOrderRequest(
    val id: String,
    val customerName: String,
    val customerPhone: String,
    val address: String,
    val items: List<OrderItemDto>,
    val total: Double,
    val totalCost: Double = 0.0,
    val profit: Double = 0.0,
    val status: String = "Pending",
    val paymentMethod: String,
    val taxAmount: Double,
    val taxRate: Double,
    val createdAt: String
)

@Serializable
data class UpdateOrderStatusRequest(
    val status: String
)

@Serializable
data class SimpleApiResponse(
    val message: String? = null,
    val error: String? = null,
    val id: String? = null,
    val url: String? = null
)

@Serializable
data class UploadImageRequest(
    val image: String
)
