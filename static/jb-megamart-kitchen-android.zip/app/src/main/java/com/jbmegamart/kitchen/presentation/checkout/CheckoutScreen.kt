package com.jbmegamart.kitchen.presentation.checkout

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jbmegamart.kitchen.data.model.CreateOrderRequest
import com.jbmegamart.kitchen.data.model.OrderItemDto
import com.jbmegamart.kitchen.domain.model.*
import com.jbmegamart.kitchen.presentation.theme.*
import com.jbmegamart.kitchen.util.PricingCalculator
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutScreen(
    items: List<CartItem>,
    orderType: OrderType,
    paymentMethod: PaymentMethod,
    settings: StoreSettings,
    onBack: () -> Unit,
    onSubmitOrder: (CreateOrderRequest) -> Unit
) {
    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var deliveryAddress by remember { mutableStateOf("") }

    // Simulated/detected customer coordinate (near Harbanspura Lahore by default)
    var customerLat by remember { mutableDoubleStateOf(31.5740) }
    var customerLng by remember { mutableDoubleStateOf(74.4250) }

    val distanceKm = remember(customerLat, customerLng, settings) {
        PricingCalculator.calculateDistanceKm(
            settings.restaurantLatitude, settings.restaurantLongitude,
            customerLat, customerLng
        )
    }

    val isOutsideRadius = orderType == OrderType.DELIVERY && distanceKm > settings.deliveryRadiusKm
    val pricing = remember(items, orderType, paymentMethod, settings) {
        PricingCalculator.calculate(items, orderType, paymentMethod, settings)
    }

    val isFormValid = customerName.isNotBlank() &&
            customerPhone.isNotBlank() &&
            (orderType == OrderType.PICKUP || deliveryAddress.isNotBlank()) &&
            !isOutsideRadius

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Checkout") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        },
        bottomBar = {
            Surface(color = DarkSurface, tonalElevation = 8.dp) {
                Button(
                    onClick = {
                        val orderId = "JB-${Random.nextInt(1000, 9999)}"
                        val now = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
                            timeZone = TimeZone.getTimeZone("UTC")
                        }.format(Date())

                        val request = CreateOrderRequest(
                            id = orderId,
                            customerName = customerName,
                            customerPhone = customerPhone,
                            address = if (orderType == OrderType.DELIVERY) deliveryAddress else "Self Pickup at Store",
                            items = items.map { item ->
                                OrderItemDto(
                                    id = item.product.id,
                                    name = item.product.name,
                                    price = item.product.price,
                                    costPrice = item.product.costPrice ?: (item.product.price * 0.5),
                                    quantity = item.quantity,
                                    variant = item.product.variant,
                                    instructions = item.instructions
                                )
                            },
                            total = pricing.total,
                            totalCost = 0.0,
                            profit = 0.0,
                            status = "Pending",
                            paymentMethod = paymentMethod.apiValue,
                            taxAmount = pricing.taxAmount,
                            taxRate = pricing.taxRate,
                            createdAt = now
                        )
                        onSubmitOrder(request)
                    },
                    enabled = isFormValid,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryRed)
                ) {
                    Text("Place Order (PKR ${pricing.total.toInt()})", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(DarkBackground)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Customer Contact Info
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Customer Information", fontWeight = FontWeight.Bold, color = DarkOnSurface)
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text("Full Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = customerPhone,
                        onValueChange = { customerPhone = it },
                        label = { Text("Phone Number (e.g. 0300-1234567)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }

            // Delivery Details (if Delivery selected)
            if (orderType == OrderType.DELIVERY) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = PrimaryRed)
                            Spacer(Modifier.width(8.dp))
                            Text("Delivery Address", fontWeight = FontWeight.Bold, color = DarkOnSurface)
                        }

                        OutlinedTextField(
                            value = deliveryAddress,
                            onValueChange = { deliveryAddress = it },
                            label = { Text("House / Street / Area Address") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )

                        Text(
                            text = "Estimated Distance: String.format(\"%.1f km\", distanceKm) (Max Radius: ${settings.deliveryRadiusKm.toInt()} km)",
                            fontSize = 12.sp,
                            color = DarkOnSurfaceVariant
                        )

                        if (isOutsideRadius) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF451010), RoundedCornerShape(8.dp))
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = OutOfStockRed)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "Selected address is outside our ${settings.deliveryRadiusKm.toInt()} km delivery radius. Please choose Pick-up instead.",
                                    color = Color.White,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            } else {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Pick-up Location", fontWeight = FontWeight.Bold, color = DarkOnSurface)
                        Spacer(Modifier.height(6.dp))
                        Text(settings.storeName, color = PrimaryRed, fontWeight = FontWeight.SemiBold)
                        Text(settings.storeAddress, fontSize = 13.sp, color = DarkOnSurfaceVariant)
                        Text("Phone: ${settings.storePhone}", fontSize = 13.sp, color = DarkOnSurfaceVariant)
                    }
                }
            }

            // Summary Recap
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceContainerHigh),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Payment Method", color = DarkOnSurfaceVariant)
                        Text(paymentMethod.displayName, color = DarkOnSurface, fontWeight = FontWeight.SemiBold)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Subtotal", color = DarkOnSurfaceVariant)
                        Text("PKR ${pricing.subtotal.toInt()}", color = DarkOnSurface)
                    }
                    if (pricing.discount > 0) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Discount", color = AccentGold)
                            Text("-PKR ${pricing.discount.toInt()}", color = AccentGold)
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Delivery Fee", color = DarkOnSurfaceVariant)
                        Text("PKR ${pricing.deliveryFee.toInt()}", color = DarkOnSurface)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("GST Tax (${(pricing.taxRate * 100).toInt()}%)", color = DarkOnSurfaceVariant)
                        Text("PKR ${pricing.taxAmount.toInt()}", color = DarkOnSurface)
                    }
                    Divider(color = DarkSurfaceContainerHighest, modifier = Modifier.padding(vertical = 4.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total to Pay", fontWeight = FontWeight.Bold, color = DarkOnSurface)
                        Text("PKR ${pricing.total.toInt()}", fontWeight = FontWeight.ExtraBold, color = PrimaryRed, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}
