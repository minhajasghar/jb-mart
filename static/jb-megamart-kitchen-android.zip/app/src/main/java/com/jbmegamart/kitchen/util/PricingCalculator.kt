package com.jbmegamart.kitchen.util

import com.jbmegamart.kitchen.domain.model.CartItem
import com.jbmegamart.kitchen.domain.model.OrderPricing
import com.jbmegamart.kitchen.domain.model.OrderType
import com.jbmegamart.kitchen.domain.model.PaymentMethod
import com.jbmegamart.kitchen.domain.model.StoreSettings
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object PricingCalculator {

    fun calculate(
        items: List<CartItem>,
        orderType: OrderType,
        paymentMethod: PaymentMethod,
        settings: StoreSettings
    ): OrderPricing {
        val subtotal = items.sumOf { it.subtotal }
        
        // Promotion discount: If subtotal > 2000 PKR, discount = 400 PKR
        val discount = if (subtotal > 2000.0) 400.0 else 0.0
        val discountedSubtotal = maxOf(0.0, subtotal - discount)
        
        // Delivery fee: 0 for Pickup, configured fee for Delivery
        val deliveryFee = if (orderType == OrderType.DELIVERY) settings.deliveryFeePkr else 0.0
        
        // Tax rate: 16% GST for Cash/COD, 5% GST for Online/Card
        val taxRate = if (paymentMethod == PaymentMethod.COD) settings.cashTaxRate else settings.cardTaxRate
        val taxAmount = discountedSubtotal * taxRate
        
        val total = discountedSubtotal + deliveryFee + taxAmount
        
        return OrderPricing(
            subtotal = subtotal,
            discount = discount,
            deliveryFee = deliveryFee,
            taxRate = taxRate,
            taxAmount = taxAmount,
            total = total
        )
    }

    // Haversine formula for calculating distance in kilometers between two geo-coordinates
    fun calculateDistanceKm(
        lat1: Double, lon1: Double,
        lat2: Double, lon2: Double
    ): Double {
        val r = 6371.0 // Earth radius in km
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }
}
