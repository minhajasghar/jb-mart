package com.jbmegamart.kitchen.data.repository

import com.jbmegamart.kitchen.data.local.AppDatabase
import com.jbmegamart.kitchen.data.local.CartItemEntity
import com.jbmegamart.kitchen.data.local.RecentOrderEntity
import com.jbmegamart.kitchen.data.model.*
import com.jbmegamart.kitchen.data.remote.NetworkClient
import com.jbmegamart.kitchen.domain.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

class AuthRepository {
    private val _currentUser = MutableStateFlow<UserSession?>(null)
    val currentUser: StateFlow<UserSession?> = _currentUser.asStateFlow()

    suspend fun login(username: String, pass: String): Result<UserSession> = withContext(Dispatchers.IO) {
        try {
            val response = NetworkClient.apiService.login(LoginRequest(username, pass))
            if (response.isSuccessful && response.body()?.user != null) {
                val dto = response.body()!!.user
                val role = when (dto.role.lowercase()) {
                    "admin" -> UserRole.ADMIN
                    "cook" -> UserRole.COOK
                    else -> UserRole.CUSTOMER
                }
                val session = UserSession(dto.id, dto.name, role)
                _currentUser.value = session
                Result.success(session)
            } else {
                Result.failure(Exception(response.errorBody()?.string() ?: "Invalid username or password"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun logout() {
        _currentUser.value = null
    }
}

class MenuRepository {
    suspend fun getCategories(): Result<List<Category>> = withContext(Dispatchers.IO) {
        try {
            val res = NetworkClient.apiService.getCategories()
            if (res.isSuccessful) {
                val list = res.body().orEmpty().map { dto ->
                    Category(
                        id = dto.id,
                        name = dto.name,
                        displayOrder = dto.displayOrder ?: 0,
                        image = dto.image,
                        hasSubcategories = dto.hasSubcategories ?: false
                    )
                }.sortedBy { it.displayOrder }
                Result.success(list)
            } else {
                Result.failure(Exception("Failed to fetch categories: ${res.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getSubcategories(): Result<List<Subcategory>> = withContext(Dispatchers.IO) {
        try {
            val res = NetworkClient.apiService.getSubcategories()
            if (res.isSuccessful) {
                val list = res.body().orEmpty().map { dto ->
                    Subcategory(
                        id = dto.id,
                        categoryId = dto.categoryId,
                        name = dto.name,
                        displayOrder = dto.displayOrder ?: 0,
                        image = dto.image
                    )
                }.sortedBy { it.displayOrder }
                Result.success(list)
            } else {
                Result.failure(Exception("Failed to fetch subcategories: ${res.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getProducts(): Result<List<Product>> = withContext(Dispatchers.IO) {
        try {
            val res = NetworkClient.apiService.getProducts()
            if (res.isSuccessful) {
                val list = res.body().orEmpty().map { dto ->
                    Product(
                        id = dto.id,
                        name = dto.name,
                        price = dto.price ?: 0.0,
                        costPrice = dto.costPrice, // Only accessible to Admin domain
                        image = dto.image,
                        categoryId = dto.categoryId,
                        subcategoryId = dto.subcategoryId,
                        variant = dto.variant,
                        isOutOfStock = dto.isOutOfStock,
                        isSpecial = dto.isSpecial,
                        displayOrder = dto.displayOrder ?: 0
                    )
                }.sortedBy { it.displayOrder }
                Result.success(list)
            } else {
                Result.failure(Exception("Failed to fetch products: ${res.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

class CartRepository(private val db: AppDatabase) {
    private val _items = MutableStateFlow<List<CartItem>>(emptyList())
    val items: StateFlow<List<CartItem>> = _items.asStateFlow()

    suspend fun loadFromDb() = withContext(Dispatchers.IO) {
        val entities = db.cartDao().getAllCartItems()
        _items.value = entities.map { e ->
            CartItem(
                product = Product(
                    id = e.productId,
                    name = e.name,
                    price = e.price,
                    costPrice = null,
                    image = e.image,
                    categoryId = null,
                    subcategoryId = null,
                    variant = e.variant,
                    isOutOfStock = false,
                    isSpecial = false,
                    displayOrder = 0
                ),
                quantity = e.quantity,
                instructions = e.instructions
            )
        }
    }

    suspend fun addToCart(product: Product, quantity: Int = 1, instructions: String = "") = withContext(Dispatchers.IO) {
        val current = _items.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == product.id }
        if (index >= 0) {
            val existing = current[index]
            current[index] = existing.copy(
                quantity = existing.quantity + quantity,
                instructions = if (instructions.isNotBlank()) instructions else existing.instructions
            )
        } else {
            current.add(CartItem(product, quantity, instructions))
        }
        _items.value = current
        val itemToPersist = current.first { it.product.id == product.id }
        db.cartDao().insertOrUpdate(
            CartItemEntity(
                productId = product.id,
                name = product.name,
                price = product.price,
                image = product.image,
                variant = product.variant,
                quantity = itemToPersist.quantity,
                instructions = itemToPersist.instructions
            )
        )
    }

    suspend fun updateQuantity(productId: String, delta: Int) = withContext(Dispatchers.IO) {
        val current = _items.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == productId }
        if (index >= 0) {
            val item = current[index]
            val newQty = item.quantity + delta
            if (newQty <= 0) {
                current.removeAt(index)
                db.cartDao().deleteById(productId)
            } else {
                current[index] = item.copy(quantity = newQty)
                db.cartDao().insertOrUpdate(
                    CartItemEntity(
                        productId = item.product.id,
                        name = item.product.name,
                        price = item.product.price,
                        image = item.product.image,
                        variant = item.product.variant,
                        quantity = newQty,
                        instructions = item.instructions
                    )
                )
            }
            _items.value = current
        }
    }

    suspend fun clearCart() = withContext(Dispatchers.IO) {
        _items.value = emptyList()
        db.cartDao().clearCart()
    }
}

class OrderRepository(private val db: AppDatabase) {
    suspend fun createOrder(request: CreateOrderRequest): Result<String> = withContext(Dispatchers.IO) {
        try {
            val res = NetworkClient.apiService.createOrder(request)
            if (res.isSuccessful) {
                db.recentOrderDao().insertOrderId(RecentOrderEntity(request.id))
                Result.success(request.id)
            } else {
                Result.failure(Exception("Failed to submit order: ${res.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getAllOrders(): Result<List<OrderDto>> = withContext(Dispatchers.IO) {
        try {
            val res = NetworkClient.apiService.getOrders()
            if (res.isSuccessful) {
                Result.success(res.body().orEmpty())
            } else {
                Result.failure(Exception("Failed to load orders: ${res.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getRecentOrderIds(): List<String> = withContext(Dispatchers.IO) {
        db.recentOrderDao().getRecentOrderIds().map { it.orderId }
    }

    suspend fun updateOrderStatus(orderId: String, newStatus: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = NetworkClient.apiService.updateOrderStatus(orderId, UpdateOrderStatusRequest(newStatus))
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to update status: ${res.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

class SettingsRepository {
    suspend fun getSettings(): Result<StoreSettings> = withContext(Dispatchers.IO) {
        try {
            val res = NetworkClient.apiService.getSettings()
            if (res.isSuccessful) {
                val map = res.body().orEmpty()
                val settings = StoreSettings(
                    storeName = map["store_name"] ?: "JB Mega Mart Kitchen",
                    storeAddress = map["store_address"] ?: "Harbanspura, Lahore",
                    storePhone = map["store_phone"] ?: "+92 300 0000000",
                    deliveryRadiusKm = map["delivery_radius"]?.toDoubleOrNull() ?: 10.0,
                    deliveryFeePkr = map["delivery_fee"]?.toDoubleOrNull() ?: 150.0,
                    cashTaxRate = map["cash_tax"]?.toDoubleOrNull() ?: 0.16,
                    cardTaxRate = map["card_tax"]?.toDoubleOrNull() ?: 0.05,
                    isKitchenOpen = map["is_kitchen_open"]?.toBoolean() ?: true
                )
                Result.success(settings)
            } else {
                Result.failure(Exception("Failed to fetch settings"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
