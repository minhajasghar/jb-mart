package com.jbmegamart.kitchen.domain.model

enum class UserRole {
    CUSTOMER, COOK, ADMIN
}

data class UserSession(
    val id: Int,
    val name: String,
    val role: UserRole
)

data class Category(
    val id: String,
    val name: String,
    val displayOrder: Int,
    val image: String?,
    val hasSubcategories: Boolean
)

data class Subcategory(
    val id: String,
    val categoryId: String,
    val name: String,
    val displayOrder: Int,
    val image: String?
)

data class Product(
    val id: String,
    val name: String,
    val price: Double,
    val costPrice: Double?, // Hidden from customer presentation
    val image: String?,
    val categoryId: String?,
    val subcategoryId: String?,
    val variant: String?,
    val isOutOfStock: Boolean,
    val isSpecial: Boolean,
    val displayOrder: Int
)

data class CartItem(
    val product: Product,
    val quantity: Int,
    val instructions: String = ""
) {
    val subtotal: Double
        get() = product.price * quantity
}

enum class OrderType {
    DELIVERY, PICKUP
}

enum class PaymentMethod(val apiValue: String, val displayName: String) {
    COD("COD", "Cash on Delivery"),
    ONLINE("Online", "Online / Card")
}

data class StoreSettings(
    val storeName: String = "JB Mega Mart Kitchen",
    val storeAddress: String = "Harbanspura, Lahore",
    val storePhone: String = "+92 300 0000000",
    val deliveryRadiusKm: Double = 10.0,
    val deliveryFeePkr: Double = 150.0,
    val cashTaxRate: Double = 0.16, // 16% GST
    val cardTaxRate: Double = 0.05, // 5% GST
    val isKitchenOpen: Boolean = true,
    val restaurantLatitude: Double = 31.5700,
    val restaurantLongitude: Double = 74.4200
)

data class OrderPricing(
    val subtotal: Double,
    val discount: Double,
    val deliveryFee: Double,
    val taxRate: Double,
    val taxAmount: Double,
    val total: Double
)

enum class OrderStatus(val raw: String, val displayName: String) {
    PENDING("Pending", "Order Received"),
    PREPARING("Preparing", "In Kitchen"),
    OUT_FOR_DELIVERY("Out for Delivery", "On the Way"),
    COMPLETED("Completed", "Delivered / Completed");

    companion object {
        fun fromRaw(raw: String): OrderStatus {
            return entries.find { it.raw.equals(raw, ignoreCase = true) } ?: PENDING
        }
    }
}
