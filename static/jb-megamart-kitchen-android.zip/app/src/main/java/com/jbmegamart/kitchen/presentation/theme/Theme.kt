package com.jbmegamart.kitchen.presentation.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PrimaryRed = Color(0xFFB91D1D)
val OnPrimary = Color(0xFFFFFFFF)
val PrimaryContainer = Color(0xFF95000B)
val OnPrimaryContainer = Color(0xFFFF9C91)

val DarkBackground = Color(0xFF131313)
val DarkSurface = Color(0xFF1C1B1B)
val DarkSurfaceContainerHigh = Color(0xFF2A2A2A)
val DarkSurfaceContainerHighest = Color(0xFF353534)
val DarkOnSurface = Color(0xFFE5E2E1)
val DarkOnSurfaceVariant = Color(0xFFA8A5A4)

val AccentGold = Color(0xFFE9C400)
val StockGreen = Color(0xFF2E7D32)
val OutOfStockRed = Color(0xFFD32F2F)

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryRed,
    onPrimary = OnPrimary,
    primaryContainer = PrimaryContainer,
    onPrimaryContainer = OnPrimaryContainer,
    background = DarkBackground,
    onBackground = DarkOnSurface,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceContainerHigh,
    onSurfaceVariant = DarkOnSurfaceVariant,
    secondary = AccentGold,
    onSecondary = Color(0xFF1B1C1C)
)

@Composable
fun JBMegaMartTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
