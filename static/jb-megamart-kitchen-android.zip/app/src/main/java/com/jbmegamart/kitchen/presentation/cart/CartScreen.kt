package com.jbmegamart.kitchen.presentation.cart

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jbmegamart.kitchen.domain.model.*
import com.jbmegamart.kitchen.presentation.theme.*
import com.jbmegamart.kitchen.util.PricingCalculator

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    items: List<CartItem>,
    settings: StoreSettings,
    onBack: () -> Unit,
    onUpdateQuantity: (String, Int) -> Unit,
    onCheckout: (OrderType, PaymentMethod) -> Unit
) {
    var orderType by remember { mutableStateOf(OrderType.DELIVERY) }
    var paymentMethod by remember { mutableStateOf(PaymentMethod.COD) }

    val pricing = remember(items, orderType, paymentMethod, settings) {
        PricingCalculator.calculate(items, orderType, paymentMethod, settings)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Your Cart (${items.sumOf { it.quantity }})") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        },
        bottomBar = {
            if (items.isNotEmpty()) {
                Surface(
                    color = DarkSurface,
                    tonalElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total Amount", color = DarkOnSurface, fontWeight = FontWeight.Bold)
                            Text("PKR ${pricing.total.toInt()}", color = PrimaryRed, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = { onCheckout(orderType, paymentMethod) },
                            enabled = settings.isKitchenOpen,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryRed)
                        ) {
                            Text(
                                if (settings.isKitchenOpen) "Proceed to Checkout" else "Kitchen Closed",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        if (items.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(DarkBackground),
                contentAlignment = Alignment.Center
            ) {
                Text("Your cart is empty", color = DarkOnSurfaceVariant)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(DarkBackground),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Order Type Selector
                item {
                    Text("Order Type", fontWeight = FontWeight.Bold, color = DarkOnSurface)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FilterChip(
                            selected = orderType == OrderType.DELIVERY,
                            onClick = { orderType = OrderType.DELIVERY },
                            label = { Text("Delivery (+PKR ${settings.deliveryFeePkr.toInt()})") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = orderType == OrderType.PICKUP,
                            onClick = { orderType = OrderType.PICKUP },
                            label = { Text("Pick-up (Free)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Payment Method Selector
                item {
                    Text("Payment Method", fontWeight = FontWeight.Bold, color = DarkOnSurface)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FilterChip(
                            selected = paymentMethod == PaymentMethod.COD,
                            onClick = { paymentMethod = PaymentMethod.COD },
                            label = { Text("Cash (16% GST)") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = paymentMethod == PaymentMethod.ONLINE,
                            onClick = { paymentMethod = PaymentMethod.ONLINE },
                            label = { Text("Online (5% GST)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Items list
                items(items) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.product.name, fontWeight = FontWeight.Bold, color = DarkOnSurface)
                                if (item.instructions.isNotBlank()) {
                                    Text("Note: ${item.instructions}", fontSize = 12.sp, color = DarkOnSurfaceVariant)
                                }
                                Text("PKR ${item.product.price.toInt()} each", fontSize = 13.sp, color = PrimaryRed)
                            }

                            // Quantity controls
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { onUpdateQuantity(item.product.id, -1) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        if (item.quantity == 1) Icons.Default.Delete else Icons.Default.Remove,
                                        contentDescription = "Decrease",
                                        tint = if (item.quantity == 1) OutOfStockRed else DarkOnSurface
                                    )
                                }
                                Text("${item.quantity}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp), color = DarkOnSurface)
                                IconButton(
                                    onClick = { onUpdateQuantity(item.product.id, 1) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Increase", tint = DarkOnSurface)
                                }
                            }
                        }
                    }
                }

                // Cost Breakdown
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceContainerHigh),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Subtotal", color = DarkOnSurfaceVariant)
                                Text("PKR ${pricing.subtotal.toInt()}", color = DarkOnSurface)
                            }
                            if (pricing.discount > 0) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Special Promo (>PKR 2000)", color = AccentGold)
                                    Text("-PKR ${pricing.discount.toInt()}", color = AccentGold, fontWeight = FontWeight.Bold)
                                }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Delivery Fee (${orderType.name.lowercase()})", color = DarkOnSurfaceVariant)
                                Text("PKR ${pricing.deliveryFee.toInt()}", color = DarkOnSurface)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Sales Tax (${(pricing.taxRate * 100).toInt()}% GST)", color = DarkOnSurfaceVariant)
                                Text("PKR ${pricing.taxAmount.toInt()}", color = DarkOnSurface)
                            }
                            Divider(color = DarkSurfaceContainerHighest, modifier = Modifier.padding(vertical = 4.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Grand Total", fontWeight = FontWeight.Bold, color = DarkOnSurface)
                                Text("PKR ${pricing.total.toInt()}", fontWeight = FontWeight.ExtraBold, color = PrimaryRed)
                            }
                        }
                    }
                }
            }
        }
    }
}
