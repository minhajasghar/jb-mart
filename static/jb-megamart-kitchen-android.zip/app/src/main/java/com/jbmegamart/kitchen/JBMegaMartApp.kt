package com.jbmegamart.kitchen

import android.app.Application

class JBMegaMartApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
