package com.jbmegamart.kitchen

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.room.Room
import com.jbmegamart.kitchen.data.local.AppDatabase
import com.jbmegamart.kitchen.data.model.OrderDto
import com.jbmegamart.kitchen.data.repository.*
import com.jbmegamart.kitchen.domain.model.*
import com.jbmegamart.kitchen.presentation.admin.AdminDashboardScreen
import com.jbmegamart.kitchen.presentation.auth.LoginScreen
import com.jbmegamart.kitchen.presentation.cart.CartScreen
import com.jbmegamart.kitchen.presentation.checkout.CheckoutScreen
import com.jbmegamart.kitchen.presentation.home.HomeScreen
import com.jbmegamart.kitchen.presentation.kitchen.KitchenScreen
import com.jbmegamart.kitchen.presentation.orders.OrderTrackingScreen
import com.jbmegamart.kitchen.presentation.orders.OrdersListScreen
import com.jbmegamart.kitchen.presentation.product.ProductDetailDialog
import com.jbmegamart.kitchen.presentation.theme.DarkBackground
import com.jbmegamart.kitchen.presentation.theme.JBMegaMartTheme
import kotlinx.coroutines.launch

enum class Screen {
    HOME, CART, CHECKOUT, TRACKING, ORDERS_LIST, LOGIN, KITCHEN, ADMIN
}

class MainActivity : ComponentActivity() {

    private lateinit var database: AppDatabase
    private lateinit var authRepository: AuthRepository
    private lateinit var menuRepository: MenuRepository
    private lateinit var cartRepository: CartRepository
    private lateinit var orderRepository: OrderRepository
    private lateinit var settingsRepository: SettingsRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize local database and repositories
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "jb_megamart_kitchen.db"
        ).fallbackToDestructiveMigration().build()

        authRepository = AuthRepository()
        menuRepository = MenuRepository()
        cartRepository = CartRepository(database)
        orderRepository = OrderRepository(database)
        settingsRepository = SettingsRepository()

        setContent {
            JBMegaMartTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkBackground
                ) {
                    AppNavigation()
                }
            }
        }
    }

    @Composable
    fun AppNavigation() {
        val scope = rememberCoroutineScope()

        var currentScreen by remember { mutableStateOf(Screen.HOME) }
        var selectedProductForDetail by remember { mutableStateOf<Product?>(null) }
        var activeOrderForTracking by remember { mutableStateOf<OrderDto?>(null) }
        var checkoutOrderType by remember { mutableStateOf(OrderType.DELIVERY) }
        var checkoutPaymentMethod by remember { mutableStateOf(PaymentMethod.COD) }
        var loginError by remember { mutableStateOf<String?>(null) }

        // State flows
        var categories by remember { mutableStateOf<List<Category>>(emptyList()) }
        var subcategories by remember { mutableStateOf<List<Subcategory>>(emptyList()) }
        var products by remember { mutableStateOf<List<Product>>(emptyList()) }
        var settings by remember { mutableStateOf(StoreSettings()) }
        var allOrders by remember { mutableStateOf<List<OrderDto>>(emptyList()) }

        val cartItems by cartRepository.items.collectAsState()
        val currentUser by authRepository.currentUser.collectAsState()

        fun refreshData() {
            scope.launch {
                cartRepository.loadFromDb()
                menuRepository.getCategories().onSuccess { categories = it }
                menuRepository.getSubcategories().onSuccess { subcategories = it }
                menuRepository.getProducts().onSuccess { products = it }
                settingsRepository.getSettings().onSuccess { settings = it }
                orderRepository.getAllOrders().onSuccess { orders ->
                    allOrders = orders
                    if (activeOrderForTracking != null) {
                        activeOrderForTracking = orders.find { it.id == activeOrderForTracking?.id }
                    }
                }
            }
        }

        LaunchedEffect(Unit) {
            refreshData()
        }

        when (currentScreen) {
            Screen.HOME -> {
                HomeScreen(
                    categories = categories,
                    subcategories = subcategories,
                    products = products,
                    settings = settings,
                    cartItemCount = cartItems.sumOf { it.quantity },
                    onProductClick = { selectedProductForDetail = it },
                    onCartClick = { currentScreen = Screen.CART },
                    onOrdersClick = { currentScreen = Screen.ORDERS_LIST },
                    onAdminLoginClick = {
                        if (currentUser != null) {
                            currentScreen = if (currentUser?.role == UserRole.ADMIN) Screen.ADMIN else Screen.KITCHEN
                        } else {
                            currentScreen = Screen.LOGIN
                        }
                    }
                )

                selectedProductForDetail?.let { prod ->
                    ProductDetailDialog(
                        product = prod,
                        onDismiss = { selectedProductForDetail = null },
                        onAddToCart = { p, qty, notes ->
                            scope.launch {
                                cartRepository.addToCart(p, qty, notes)
                                Toast.makeText(this@MainActivity, "Added to Cart!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }
            }

            Screen.CART -> {
                CartScreen(
                    items = cartItems,
                    settings = settings,
                    onBack = { currentScreen = Screen.HOME },
                    onUpdateQuantity = { id, delta ->
                        scope.launch { cartRepository.updateQuantity(id, delta) }
                    },
                    onCheckout = { orderType, paymentMethod ->
                        checkoutOrderType = orderType
                        checkoutPaymentMethod = paymentMethod
                        currentScreen = Screen.CHECKOUT
                    }
                )
            }

            Screen.CHECKOUT -> {
                CheckoutScreen(
                    items = cartItems,
                    orderType = checkoutOrderType,
                    paymentMethod = checkoutPaymentMethod,
                    settings = settings,
                    onBack = { currentScreen = Screen.CART },
                    onSubmitOrder = { request ->
                        scope.launch {
                            orderRepository.createOrder(request).onSuccess { orderId ->
                                cartRepository.clearCart()
                                Toast.makeText(this@MainActivity, "Order placed successfully!", Toast.LENGTH_LONG).show()
                                refreshData()
                                activeOrderForTracking = OrderDto(
                                    id = request.id,
                                    customerName = request.customerName,
                                    customerPhone = request.customerPhone,
                                    address = request.address,
                                    items = request.items,
                                    total = request.total,
                                    status = request.status,
                                    paymentMethod = request.paymentMethod,
                                    taxAmount = request.taxAmount,
                                    taxRate = request.taxRate
                                )
                                currentScreen = Screen.TRACKING
                            }.onFailure { err ->
                                Toast.makeText(this@MainActivity, "Order failed: ${err.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                )
            }

            Screen.ORDERS_LIST -> {
                OrdersListScreen(
                    orders = allOrders,
                    onBack = { currentScreen = Screen.HOME },
                    onRefresh = { refreshData() },
                    onSelectOrder = { order ->
                        activeOrderForTracking = order
                        currentScreen = Screen.TRACKING
                    }
                )
            }

            Screen.TRACKING -> {
                OrderTrackingScreen(
                    order = activeOrderForTracking,
                    onBack = { currentScreen = Screen.HOME },
                    onRefresh = { refreshData() }
                )
            }

            Screen.LOGIN -> {
                LoginScreen(
                    onBack = { currentScreen = Screen.HOME },
                    errorMessage = loginError,
                    onLogin = { u, p ->
                        scope.launch {
                            authRepository.login(u, p).onSuccess { session ->
                                loginError = null
                                currentScreen = if (session.role == UserRole.ADMIN) Screen.ADMIN else Screen.KITCHEN
                            }.onFailure { err ->
                                loginError = err.message ?: "Authentication failed"
                            }
                        }
                    }
                )
            }

            Screen.KITCHEN -> {
                KitchenScreen(
                    orders = allOrders,
                    onUpdateStatus = { orderId, newStatus ->
                        scope.launch {
                            orderRepository.updateOrderStatus(orderId, newStatus).onSuccess {
                                refreshData()
                                Toast.makeText(this@MainActivity, "Order marked as $newStatus", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    onRefresh = { refreshData() },
                    onLogout = {
                        authRepository.logout()
                        currentScreen = Screen.HOME
                    }
                )
            }

            Screen.ADMIN -> {
                AdminDashboardScreen(
                    orders = allOrders,
                    products = products,
                    settings = settings,
                    onRefresh = { refreshData() },
                    onLogout = {
                        authRepository.logout()
                        currentScreen = Screen.HOME
                    },
                    onToggleKitchenStatus = { isOpen ->
                        scope.launch {
                            settings = settings.copy(isKitchenOpen = isOpen)
                            Toast.makeText(this@MainActivity, "Kitchen status updated", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            }
        }
    }
}
