package com.jbmegamart.kitchen.presentation.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.jbmegamart.kitchen.domain.model.*
import com.jbmegamart.kitchen.presentation.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    categories: List<Category>,
    subcategories: List<Subcategory>,
    products: List<Product>,
    settings: StoreSettings,
    cartItemCount: Int,
    onProductClick: (Product) -> Unit,
    onCartClick: () -> Unit,
    onOrdersClick: () -> Unit,
    onAdminLoginClick: () -> Unit
) {
    var selectedCategoryId by remember(categories) {
        mutableStateOf(categories.firstOrNull()?.id ?: "")
    }

    val selectedCategory = categories.find { it.id == selectedCategoryId }
    val categorySubcategories = remember(selectedCategoryId, subcategories) {
        subcategories.filter { it.categoryId == selectedCategoryId }
    }

    var selectedSubcategoryId by remember(categorySubcategories) {
        mutableStateOf<String?>(null)
    }

    val displayedProducts = remember(selectedCategoryId, selectedSubcategoryId, products) {
        products.filter { p ->
            val matchCategory = p.categoryId == selectedCategoryId
            val matchSubcategory = selectedSubcategoryId == null || p.subcategoryId == selectedSubcategoryId
            matchCategory && matchSubcategory
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = settings.storeName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = if (settings.isKitchenOpen) "● Kitchen Open • Fresh Orders" else "○ Kitchen Closed",
                            fontSize = 12.sp,
                            color = if (settings.isKitchenOpen) StockGreen else OutOfStockRed
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onOrdersClick) {
                        Icon(Icons.Default.Receipt, contentDescription = "My Orders")
                    }
                    IconButton(onClick = onCartClick) {
                        BadgedBox(
                            badge = {
                                if (cartItemCount > 0) {
                                    Badge(containerColor = PrimaryRed) {
                                        Text(cartItemCount.toString(), color = Color.White)
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = "Cart")
                        }
                    }
                    IconButton(onClick = onAdminLoginClick) {
                        Icon(Icons.Default.Person, contentDescription = "Staff Login")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBackground
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(DarkBackground),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Closed Banner
            if (!settings.isKitchenOpen) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF451010))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = OutOfStockRed)
                            Spacer(Modifier.width(12.dp))
                            Text(
                                "Kitchen is currently closed for incoming orders. You may still browse the menu.",
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            // Categories horizontal selector
            item {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(categories) { cat ->
                        val isSelected = cat.id == selectedCategoryId
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                selectedCategoryId = cat.id
                                selectedSubcategoryId = null
                            },
                            label = { Text(cat.name, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryRed,
                                selectedLabelColor = Color.White,
                                containerColor = DarkSurfaceContainerHigh,
                                labelColor = DarkOnSurface
                            )
                        )
                    }
                }
            }

            // Subcategories if applicable
            if (categorySubcategories.isNotEmpty()) {
                item {
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        item {
                            SuggestionChip(
                                onClick = { selectedSubcategoryId = null },
                                label = { Text("All", fontSize = 12.sp) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = if (selectedSubcategoryId == null) AccentGold else DarkSurfaceContainerHighest,
                                    labelColor = if (selectedSubcategoryId == null) Color.Black else DarkOnSurface
                                )
                            )
                        }
                        items(categorySubcategories) { sub ->
                            val isSubSelected = sub.id == selectedSubcategoryId
                            SuggestionChip(
                                onClick = { selectedSubcategoryId = sub.id },
                                label = { Text(sub.name, fontSize = 12.sp) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = if (isSubSelected) AccentGold else DarkSurfaceContainerHighest,
                                    labelColor = if (isSubSelected) Color.Black else DarkOnSurface
                                )
                            )
                        }
                    }
                }
            }

            // Products grid / list
            if (displayedProducts.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No items found in this section", color = DarkOnSurfaceVariant)
                    }
                }
            } else {
                items(displayedProducts) { product ->
                    ProductCard(
                        product = product,
                        onClick = { onProductClick(product) }
                    )
                }
            }
        }
    }
}

@Composable
fun ProductCard(
    product: Product,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Image
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(DarkSurfaceContainerHigh)
            ) {
                AsyncImage(
                    model = product.image,
                    contentDescription = product.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                if (product.isSpecial) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .background(AccentGold, RoundedCornerShape(bottomEnd = 6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("★ Chef Special", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                }
            }

            Spacer(Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = product.name,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = DarkOnSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (!product.variant.isNullOrBlank()) {
                    Text(
                        text = product.variant,
                        fontSize = 12.sp,
                        color = DarkOnSurfaceVariant
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PKR ${product.price.toInt()}",
                        color = PrimaryRed,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )

                    if (product.isOutOfStock) {
                        Text(
                            text = "Out of Stock",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = OutOfStockRed
                        )
                    } else {
                        FilledTonalButton(
                            onClick = onClick,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = PrimaryContainer,
                                contentColor = OnPrimary
                            )
                        ) {
                            Text("+ Add", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
