package com.jbmegamart.kitchen.data.remote

import com.jbmegamart.kitchen.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    // Auth
    @POST("auth/login")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>

    // Categories
    @GET("categories")
    suspend fun getCategories(): Response<List<CategoryDto>>

    @POST("categories")
    suspend fun createCategory(@Body category: CategoryDto): Response<SimpleApiResponse>

    @PUT("categories/{id}")
    suspend fun updateCategory(@Path("id") id: String, @Body category: CategoryDto): Response<SimpleApiResponse>

    @DELETE("categories/{id}")
    suspend fun deleteCategory(@Path("id") id: String): Response<SimpleApiResponse>

    // Subcategories
    @GET("subcategories")
    suspend fun getSubcategories(): Response<List<SubcategoryDto>>

    @POST("subcategories")
    suspend fun createSubcategory(@Body subcategory: SubcategoryDto): Response<SimpleApiResponse>

    @PUT("subcategories/{id}")
    suspend fun updateSubcategory(@Path("id") id: String, @Body subcategory: SubcategoryDto): Response<SimpleApiResponse>

    @DELETE("subcategories/{id}")
    suspend fun deleteSubcategory(@Path("id") id: String): Response<SimpleApiResponse>

    // Products
    @GET("products")
    suspend fun getProducts(): Response<List<ProductDto>>

    @POST("products")
    suspend fun createProduct(@Body product: ProductDto): Response<SimpleApiResponse>

    @PUT("products/{id}")
    suspend fun updateProduct(@Path("id") id: String, @Body product: ProductDto): Response<SimpleApiResponse>

    @DELETE("products/{id}")
    suspend fun deleteProduct(@Path("id") id: String): Response<SimpleApiResponse>

    // Orders
    @GET("orders")
    suspend fun getOrders(): Response<List<OrderDto>>

    @POST("orders")
    suspend fun createOrder(@Body order: CreateOrderRequest): Response<SimpleApiResponse>

    @POST("orders/{id}/status")
    suspend fun updateOrderStatus(
        @Path("id") orderId: String,
        @Body request: UpdateOrderStatusRequest
    ): Response<SimpleApiResponse>

    // Settings
    @GET("settings")
    suspend fun getSettings(): Response<Map<String, String>>

    @POST("settings-update")
    suspend fun updateSettings(@Body settings: Map<String, String>): Response<SimpleApiResponse>

    // Users (Staff)
    @GET("users")
    suspend fun getUsers(): Response<List<UserDto>>

    @POST("users")
    suspend fun createUser(@Body user: Map<String, String>): Response<SimpleApiResponse>

    @DELETE("users/{id}")
    suspend fun deleteUser(@Path("id") userId: Int): Response<SimpleApiResponse>

    // Media
    @POST("upload")
    suspend fun uploadImage(@Body request: UploadImageRequest): Response<SimpleApiResponse>
}
