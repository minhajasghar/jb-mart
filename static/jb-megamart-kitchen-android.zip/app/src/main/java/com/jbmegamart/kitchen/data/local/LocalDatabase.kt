package com.jbmegamart.kitchen.data.local

import androidx.room.*

@Entity(tableName = "cart_items")
data class CartItemEntity(
    @PrimaryKey val productId: String,
    val name: String,
    val price: Double,
    val image: String?,
    val variant: String?,
    val quantity: Int,
    val instructions: String
)

@Dao
interface CartDao {
    @Query("SELECT * FROM cart_items")
    suspend fun getAllCartItems(): List<CartItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(item: CartItemEntity)

    @Query("DELETE FROM cart_items WHERE productId = :productId")
    suspend fun deleteById(productId: String)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()
}

@Entity(tableName = "recent_orders")
data class RecentOrderEntity(
    @PrimaryKey val orderId: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface RecentOrderDao {
    @Query("SELECT * FROM recent_orders ORDER BY createdAt DESC")
    suspend fun getRecentOrderIds(): List<RecentOrderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrderId(order: RecentOrderEntity)
}

@Database(entities = [CartItemEntity::class, RecentOrderEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun cartDao(): CartDao
    abstract fun recentOrderDao(): RecentOrderDao
}
