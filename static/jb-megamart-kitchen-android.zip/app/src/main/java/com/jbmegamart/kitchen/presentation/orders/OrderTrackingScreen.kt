package com.jbmegamart.kitchen.presentation.orders

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jbmegamart.kitchen.data.model.OrderDto
import com.jbmegamart.kitchen.domain.model.OrderStatus
import com.jbmegamart.kitchen.presentation.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderTrackingScreen(
    order: OrderDto?,
    onBack: () -> Unit,
    onRefresh: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (order != null) "Order ${order.id}" else "Order Details") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onRefresh) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        }
    ) { padding ->
        if (order == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(DarkBackground),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = PrimaryRed)
            }
        } else {
            val currentStatus = OrderStatus.fromRaw(order.status)

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(DarkBackground),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Tracking Status Stepper
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Current Status", fontWeight = FontWeight.Bold, color = DarkOnSurface)
                            Spacer(Modifier.height(14.dp))
                            StatusStepper(currentStatus = currentStatus)
                        }
                    }
                }

                // Delivery Info
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Recipient & Delivery", fontWeight = FontWeight.Bold, color = DarkOnSurface)
                            Text("Name: ${order.customerName}", color = DarkOnSurface)
                            if (!order.customerPhone.isNullOrBlank()) {
                                Text("Phone: ${order.customerPhone}", color = DarkOnSurfaceVariant, fontSize = 13.sp)
                            }
                            if (!order.address.isNullOrBlank()) {
                                Text("Address: ${order.address}", color = DarkOnSurfaceVariant, fontSize = 13.sp)
                            }
                            Text("Payment: ${order.paymentMethod}", color = AccentGold, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                // Items list
                item {
                    Text("Order Items (${order.items.size})", fontWeight = FontWeight.Bold, color = DarkOnSurface)
                }

                items(order.items) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceContainerHigh),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("${item.quantity}x ${item.name}", fontWeight = FontWeight.SemiBold, color = DarkOnSurface)
                                if (!item.instructions.isNullOrBlank()) {
                                    Text("Note: ${item.instructions}", fontSize = 11.sp, color = DarkOnSurfaceVariant)
                                }
                            }
                            Text(
                                "PKR ${((item.price ?: 0.0) * item.quantity).toInt()}",
                                fontWeight = FontWeight.Bold,
                                color = PrimaryRed
                            )
                        }
                    }
                }

                // Total Summary
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Sales Tax (${(order.taxRate * 100).toInt()}% GST)", color = DarkOnSurfaceVariant)
                                Text("PKR ${order.taxAmount.toInt()}", color = DarkOnSurface)
                            }
                            Divider(color = DarkSurfaceContainerHighest, modifier = Modifier.padding(vertical = 4.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Paid / Due", fontWeight = FontWeight.Bold, color = DarkOnSurface)
                                Text("PKR ${order.total.toInt()}", fontWeight = FontWeight.ExtraBold, color = PrimaryRed, fontSize = 16.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusStepper(currentStatus: OrderStatus) {
    val steps = listOf(
        OrderStatus.PENDING to "Received",
        OrderStatus.PREPARING to "Preparing",
        OrderStatus.OUT_FOR_DELIVERY to "Dispatched",
        OrderStatus.COMPLETED to "Delivered"
    )

    val currentIndex = steps.indexOfFirst { it.first == currentStatus }.let { if (it == -1) 0 else it }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        steps.forEachIndexed { index, pair ->
            val isDone = index <= currentIndex
            val isCurrent = index == currentIndex

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isCurrent -> PrimaryRed
                                isDone -> StockGreen
                                else -> DarkSurfaceContainerHighest
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isDone && !isCurrent) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    } else {
                        Text("${index + 1}", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(
                        pair.second,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                        color = if (isDone) DarkOnSurface else DarkOnSurfaceVariant,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}
