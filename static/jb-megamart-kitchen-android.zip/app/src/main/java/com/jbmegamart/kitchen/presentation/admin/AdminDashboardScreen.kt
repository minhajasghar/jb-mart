package com.jbmegamart.kitchen.presentation.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jbmegamart.kitchen.data.model.OrderDto
import com.jbmegamart.kitchen.domain.model.Product
import com.jbmegamart.kitchen.domain.model.StoreSettings
import com.jbmegamart.kitchen.presentation.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    orders: List<OrderDto>,
    products: List<Product>,
    settings: StoreSettings,
    onRefresh: () -> Unit,
    onLogout: () -> Unit,
    onToggleKitchenStatus: (Boolean) -> Unit
) {
    val totalRevenue = remember(orders) {
        orders.sumOf { it.total }
    }
    val totalCost = remember(orders) {
        orders.sumOf { it.totalCost ?: 0.0 }
    }
    val totalProfit = remember(orders) {
        orders.sumOf { it.profit ?: (it.total - (it.totalCost ?: 0.0)) }
    }
    val activeOrdersCount = remember(orders) {
        orders.count { it.status.lowercase() != "completed" }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Manager / Admin Portal") },
                actions = {
                    IconButton(onClick = onRefresh) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                    IconButton(onClick = onLogout) {
                        Icon(Icons.Default.ExitToApp, contentDescription = "Logout")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(DarkBackground),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Kitchen Toggle
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Kitchen Status", fontWeight = FontWeight.Bold, color = DarkOnSurface)
                            Text(
                                if (settings.isKitchenOpen) "Accepting online orders" else "Orders paused",
                                fontSize = 12.sp,
                                color = DarkOnSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.isKitchenOpen,
                            onCheckedChange = { onToggleKitchenStatus(it) }
                        )
                    }
                }
            }

            // Financial KPIs
            item {
                Text("Business Metrics (Admin View)", fontWeight = FontWeight.Bold, color = DarkOnSurface)
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    KpiCard(
                        title = "Gross Revenue",
                        value = "PKR ${totalRevenue.toInt()}",
                        color = PrimaryRed,
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Net Profit",
                        value = "PKR ${totalProfit.toInt()}",
                        color = StockGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    KpiCard(
                        title = "Total Orders",
                        value = "${orders.size}",
                        color = AccentGold,
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Active Orders",
                        value = "$activeOrdersCount",
                        color = Color(0xFF0288D1),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Quick Menu Status
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Inventory & Menu Overview", fontWeight = FontWeight.Bold, color = DarkOnSurface)
                        val outOfStockCount = products.count { it.isOutOfStock }
                        val specialsCount = products.count { it.isSpecial }
                        Text("• Total Active Menu Items: ${products.size}", color = DarkOnSurface)
                        Text("• Items Out of Stock: $outOfStockCount", color = if (outOfStockCount > 0) OutOfStockRed else DarkOnSurfaceVariant)
                        Text("• Chef Specials: $specialsCount", color = AccentGold)
                    }
                }
            }
        }
    }
}

@Composable
fun KpiCard(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, fontSize = 12.sp, color = DarkOnSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = color)
        }
    }
}
