package com.jbmegamart.kitchen.presentation.kitchen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jbmegamart.kitchen.data.model.OrderDto
import com.jbmegamart.kitchen.presentation.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KitchenScreen(
    orders: List<OrderDto>,
    onUpdateStatus: (String, String) -> Unit,
    onRefresh: () -> Unit,
    onLogout: () -> Unit
) {
    // Only display active kitchen orders (exclude Completed or show them at the very bottom)
    val activeOrders = remember(orders) {
        orders.filter { it.status.lowercase() != "completed" }
            .sortedBy { it.createdAt ?: "" } // Oldest first for kitchen prep
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Kitchen Display System (KDS)") },
                actions = {
                    IconButton(onClick = onRefresh) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                    IconButton(onClick = onLogout) {
                        Icon(Icons.Default.ExitToApp, contentDescription = "Logout")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        }
    ) { padding ->
        if (activeOrders.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(DarkBackground),
                contentAlignment = Alignment.Center
            ) {
                Text("All kitchen tickets are clear! 🎉", color = DarkOnSurfaceVariant)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(DarkBackground),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(activeOrders) { order ->
                    KitchenOrderCard(
                        order = order,
                        onAdvanceStatus = { newStatus ->
                            onUpdateStatus(order.id, newStatus)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun KitchenOrderCard(
    order: OrderDto,
    onAdvanceStatus: (String) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: ID and Status badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(order.id, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = DarkOnSurface)
                val statusColor = when (order.status.lowercase()) {
                    "pending" -> Color(0xFFE65100) // Orange
                    "preparing" -> Color(0xFFFBC02D) // Yellow
                    "out for delivery" -> Color(0xFF0288D1) // Blue
                    else -> StockGreen
                }
                Surface(
                    color = statusColor.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = order.status,
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            Divider(color = DarkSurfaceContainerHighest)
            Spacer(Modifier.height(8.dp))

            // Order items
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                order.items.forEach { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${item.quantity}x ${item.name}",
                            fontWeight = FontWeight.SemiBold,
                            color = DarkOnSurface,
                            fontSize = 14.sp
                        )
                        if (!item.variant.isNullOrBlank()) {
                            Text(item.variant, color = DarkOnSurfaceVariant, fontSize = 12.sp)
                        }
                    }
                    if (!item.instructions.isNullOrBlank()) {
                        Text(
                            text = "⚠ Note: ${item.instructions}",
                            color = AccentGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // Quick advance actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                when (order.status.lowercase()) {
                    "pending" -> {
                        Button(
                            onClick = { onAdvanceStatus("Preparing") },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryRed),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Start Preparing", fontWeight = FontWeight.Bold)
                        }
                    }
                    "preparing" -> {
                        Button(
                            onClick = { onAdvanceStatus("Out for Delivery") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Dispatch / Ready", fontWeight = FontWeight.Bold)
                        }
                    }
                    "out for delivery" -> {
                        Button(
                            onClick = { onAdvanceStatus("Completed") },
                            colors = ButtonDefaults.buttonColors(containerColor = StockGreen),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Mark Completed", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
