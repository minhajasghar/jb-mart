package com.jbmegamart.kitchen

import com.jbmegamart.kitchen.domain.model.*
import com.jbmegamart.kitchen.util.PricingCalculator
import org.junit.Assert.assertEquals
import org.junit.Test

class PricingCalculatorTest {

    private val sampleProduct = Product(
        id = "p1",
        name = "Zinger Burger",
        price = 600.0,
        costPrice = 300.0,
        image = null,
        categoryId = "cat-burgers",
        subcategoryId = null,
        variant = "Regular",
        isOutOfStock = false,
        isSpecial = true,
        displayOrder = 1
    )

    private val defaultSettings = StoreSettings(
        deliveryRadiusKm = 10.0,
        deliveryFeePkr = 150.0,
        cashTaxRate = 0.16,
        cardTaxRate = 0.05
    )

    @Test
    fun testCashPickupUnderDiscountThreshold() {
        val items = listOf(CartItem(sampleProduct, 2)) // 1200 PKR
        val result = PricingCalculator.calculate(
            items = items,
            orderType = OrderType.PICKUP,
            paymentMethod = PaymentMethod.COD,
            settings = defaultSettings
        )

        assertEquals(1200.0, result.subtotal, 0.01)
        assertEquals(0.0, result.discount, 0.01)
        assertEquals(0.0, result.deliveryFee, 0.01)
        assertEquals(0.16, result.taxRate, 0.001)
        assertEquals(192.0, result.taxAmount, 0.01) // 1200 * 0.16
        assertEquals(1392.0, result.total, 0.01)
    }

    @Test
    fun testOnlineDeliveryOverDiscountThreshold() {
        val items = listOf(CartItem(sampleProduct, 4)) // 2400 PKR
        val result = PricingCalculator.calculate(
            items = items,
            orderType = OrderType.DELIVERY,
            paymentMethod = PaymentMethod.ONLINE,
            settings = defaultSettings
        )

        assertEquals(2400.0, result.subtotal, 0.01)
        assertEquals(400.0, result.discount, 0.01) // 2400 - 400 = 2000 discounted subtotal
        assertEquals(150.0, result.deliveryFee, 0.01)
        assertEquals(0.05, result.taxRate, 0.001)
        assertEquals(100.0, result.taxAmount, 0.01) // 2000 * 0.05
        assertEquals(2250.0, result.total, 0.01) // 2000 + 150 + 100
    }

    @Test
    fun testDistanceCalculation() {
        // Distance from restaurant (31.5700, 74.4200) to nearby Harbanspura point
        val dist = PricingCalculator.calculateDistanceKm(
            31.5700, 74.4200,
            31.5800, 74.4300
        )
        // Expected ~1.46 km
        assert(dist in 1.0..2.0)
    }
}
